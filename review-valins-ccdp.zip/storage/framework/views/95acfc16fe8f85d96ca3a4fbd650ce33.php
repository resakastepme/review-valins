<?php $__env->startSection('title'); ?>
    Preview
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin/dataTables.bootstrap4.min.css')); ?>">
    <style>
        #pointer {
            cursor: default
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
    // if(Session::get('preview_access') != 'granted'){redirect()->to('/auth')->send()}
    ?>
    <?php error_reporting(0); ?>
    <div class="container p-3">
        <div class="row">
            <div class="col-md-6 d-flex">

                <h2 class="me-2"> Preview: </h2>
                <div class="card bg-success p-2" id="pointer" style="background-color: green">
                    <div class="card-title text-white">
                        <i class="fa-solid fa-file-excel fa-lg me-1"></i>
                        <?php echo e(Session('fileName')); ?>

                    </div>
                </div>

            </div>
            <div class="col-md-6">
                <div class="row d-flex justify-content-end">
                    <div class="col-auto d-flex justify-content-end">
                        <div class="card bg-secondary me-2">
                            <div class="card-body" style="cursor: pointer;">
                                <h6 style="color: white;" id="batalkan"> Batalkan </h6>
                            </div>
                        </div>
                        <div class="card bg-primary" id="<?php echo e($previewValid[0]['id_valins'] != '' ? 'submitValid' : '~'); ?>"
                            style="cursor: <?php echo e($previewValid[0]['id_valins'] != '' ? 'pointer' : 'not-allowed'); ?>">
                            <div class="card-body">
                                <h6 style="color: white;"> Submit </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($previewNotValid[0]['id_valins'] != ''): ?>
        <section class="m-4" id="dataError" style="display: block">
            <h5 class="text-center" style="color: red"><span class="fa-solid fa-triangle-exclamation fa-fade"></span> DATA
                TIDAK
                VALID TERDETEKSI </h5>
            <div class="card bg-danger p-3 rounded shadow border-0">
                <div class="card-body">

                    <table id="tableDataPreviewError" style="width:100%"
                        class="table table-striped table-bordered table-hover" border="1">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Timestamp</th>
                                <th>Witel</th>
                                <th>ID Valins</th>
                                <th>Rekon</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $previewNotValid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notValid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($notValid->timestamp_bawaan); ?></td>
                                    <td><?php echo e($notValid->witel); ?></td>
                                    <td><?php echo e($notValid->id_valins); ?></td>
                                    <td><?php echo e($notValid->rekon); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </section>
    <?php endif; ?>
    <?php if($previewValid[0]['id_valins'] != ''): ?>
        <section id="dataSuccess" class="m-4" id="dataSuccess" style="display:block">
            <h5 class="text-center" style="color: green"><span class="fa-solid fa-thumbs-up fa-fade"></span> DATA VALID
            </h5>
            <div class="card bg-success p-3 rounded shadow border-0">
                <div class="card-body">

                    <table id="tableDataPreviewSuccess" style="width:100%"
                        class="table table-striped table-bordered table-hover" border="1">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Timestamp</th>
                                <th>Witel</th>
                                <th>ID Valins</th>
                                <th>Rekon</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $previewValid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Valid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($Valid->timestamp_bawaan); ?></td>
                                    <td><?php echo e($Valid->witel); ?></td>
                                    <td><?php echo e($Valid->id_valins); ?></td>
                                    <td><?php echo e($Valid->rekon); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/admin/pengguna/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/admin/pengguna/dataTables.bootstrap4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/admin/data/preview.js')); ?>"></script>
    <script type="text/javascript">
        var excelFailed = 'Session('
        excelFailed ')';

        function excelFailed() {
            Swal.fire({
                title: "Error",
                text: "Kesalahan pada sistem, coba lagi nanti!",
                icon: "error"
            });
        }
        (excelFailed ? excelFailed() : '')
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\review-valins\resources\views/admin/data/preview.blade.php ENDPATH**/ ?>