document.addEventListener('DOMContentLoaded', function () {

    // $('#penggunaBtn').on('click', function () {

    //     const role = '{{ Session("role") }}';
    //     console.log(role);

    //     document.getElementById('penggunaBtn').classList.remove('bg-light');
    //     document.getElementById('penggunaBtn').classList.add('bg-primary');

    // });

    $('#dataBtn').on('click', function () {

        document.getElementById('dataBtn').classList.remove('bg-light');
        document.getElementById('dataBtn').classList.add('bg-primary');

    });

    $('#beriTugasBtn').on('click', function () {

        document.getElementById('beriTugasBtn').classList.remove('bg-light');
        document.getElementById('beriTugasBtn').classList.add('bg-primary');

    });

    $('#tugasBtn').on('click', function () {

        document.getElementById('tugasBtn').classList.remove('bg-light');
        document.getElementById('tugasBtn').classList.add('bg-primary');

    });

    $('#penggunaBtn').on('click', function () {

        document.getElementById('penggunaBtn').classList.remove('bg-light');
        document.getElementById('penggunaBtn').classList.add('bg-primary');

    });


});
